export const unions = new webix.DataCollection({
	url:'/api/central/union'
});
